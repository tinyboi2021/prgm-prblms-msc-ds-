num = 45

if (num % 3 == 0 and num % 5 == 0):
    print("The num %d is divisible by 15" %(num))

elif (num % 3 == 0):
    print("The num %d is divisible by 3" %(num))

elif (num % 5 == 0):
    print("The num %d is divisible by 5" %(num))

else:
    print("The num %d is not divisible by 3, 5 or 15" %(num))




""" nums = [12, 14, 15, 25, 28, 20, 50, 45, 75]

for num in nums:
    if(num % 3 == 0 and num % 5 == 0):
        print("The num %d is divisible by 15" %(num))
    elif(num % 3 == 0):
        print("The num %d is divisible by 3" %(num))
    elif(num % 5 == 0):
        print("The num %d is divisible by 5" %(num))
    else:
        print("The num %d is not divisible by 3, 5 or 15" %(num)) """