from array import *

arr = array('i', [9, 7, 3, 2, 4, 5])
print(arr)


char_arr = array('u', ['a', 'b', 'c', 'd'])
print(char_arr)


print(arr.buffer_info())
print(char_arr.buffer_info())


arr.reverse()
print(arr)


print(arr[4])

for i in range(len(arr)) :
    print(arr[i])


for element in arr :
    print(element)



new_arr = array(arr.typecode, (val for val in arr))

print(new_arr)