""" str.lower() method """

text = "Hello, World!"
print(text.lower())


""" str.upper() method """

text = "hello, world!"
print(text.upper())


""" str.capitalize() method """

text = "hello, WORLD!"
print(text.capitalize())


""" str.title() method """

text = "hello, world!"
print(text.title()) 


""" str.strip() method """

text = "  Hello, World!  "
print(text.strip()) 


""" str.lstrip() and str.rstrip() methods """

text = "  Hello, World!  "
print(text.lstrip())  
print(text.rstrip()) 


""" str.split(separator) method """

text = "Hello, World!"
print(text.split())

csv_text = "apple,banana,cherry"
print(csv_text.split(',')) 


""" str.join(iterable) method """

words = ['Hello', 'World']
print(' '.join(words))


""" str.replace(old, new) method """

text = "Hello, World!"
print(text.replace("World", "Python"))


""" str.find(substring) method """

text = "Hello, World!"
print(text.find("World"))  # Output: 7


""" str.count(substring) method """

text = "Hello, World! World!"
print(text.count("World")) 


""" str.startswith(prefix) and str.endswith(suffix) methods """

text = "Hello, World!"
print(text.startswith("Hello"))  # Output: True
print(text.endswith("World!"))   # Output: True


""" str.isalpha() method """

text = "Hello"
print(text.isalpha())  # Output: True

text = "Hello123"
print(text.isalpha())  # Output: False


""" str.isdigit() method """

text = "12345"
print(text.isdigit())  # Output: True

text = "12345abc"
print(text.isdigit())  # Output: False


""" str.isalnum() method """

text = "Hello123"
print(text.isalnum())  # Output: True

text = "Hello 123"
print(text.isalnum())  # Output: False


""" str.isspace() method """

text = "   "
print(text.isspace())  # Output: True

text = "Hello"
print(text.isspace())  # Output: False


""" str.swapcase() method """

text = "Hello, World!"
print(text.swapcase())  # Output: "hELLO, wORLD!"


""" str.zfill(width) method """

text = "42"
print(text.zfill(5))  # Output: "00042"


""" str.center(width, fillchar) method """

text = "Hello"
print(text.center(10, '-'))  # Output: "--Hello---"


""" str.ljust(width, fillchar) and str.rjust(width, fillchar)methods """

text = "Hello"
print(text.ljust(10, '-'))  # Output: "Hello-----"
print(text.rjust(10, '-'))  # Output: "-----Hello"


""" str.partition(separator) method """

text = "Hello, World!"
print(text.partition(','))  # Output: ('Hello', ',', ' World!')


""" str.splitlines(keepends=False) method """

text = "Hello\nWorld!\nPython"
print(text.splitlines())  # Output: ['Hello', 'World!', 'Python']
print(text.splitlines(keepends = True))  # Output: ['Hello', 'World!', 'Python']