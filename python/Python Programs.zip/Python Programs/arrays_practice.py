from array import *

arr1 = array('u', ['a', 'b', 'c', 'd'])
print(arr1)


arr = array('i',[1,2,3,4,5])
print(arr)

print(arr.buffer_info())

print(arr.typecode)
print(arr.itemsize)

print(arr.index(2))
