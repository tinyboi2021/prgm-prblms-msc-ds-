""" _____String Literals_____ """


"""1. `f` Strings Example """

name = "Maria"
age = 22

print(f"My name is {name} and I'm {age} years old")

# exp = f"My name is {name} and I'm {age} years old"
# print(exp)


"""2. Raw Strings Example """

print(r"C:\Downloads\New Folder")


"""3. Byte String Literals Example """

print(b"A Byte String")


"""4. Unicode String Literals Example """

unicode_string = u"Hello, World!"
print(unicode_string)


""" _____Other Methods_____ """

"""1. Triple Quoted Strings Example """

multi_line_string = """This is a string
that spans multiple lines."""
print(multi_line_string)


"""2. Escape Sequences Example """

print("Line 1\nLine 2")
print("Term1\tTerm2")
print("C:\\Downloads\\New Folder")
print('\'All is Well\'')
print("\"All is Well\"")


""" _____String Formatting Methods_____ """


"""1. Old-Style Formatting Using % Operator """

name = "Raju"
age = 30
formatted_string = "My name is %s and I'm %d years old" %(name, age)
print(formatted_string)


"""2. String Formatting Using str.format() Method Example """

name = "Karthik"
age = 25.4564564567
print("My name is {} and I am {} years old.".format(name, age))


"""3. `f` Strings or Formatted Strings Example """

name = "Maria"
age = 22

print(f"My name is {name} and I'm {age + 2} years old")


"""4. String Formatting Using Template Strings """

from string import Template
template = Template("My name is $name and I am $age years old.")
formatted_string = template.substitute(name="Aswin", age=28)
print(formatted_string)


from string import Template
t = Template("Hello, $name!")
print(t.substitute(name="Aswin"))  # Output: Hello, Aswin!
