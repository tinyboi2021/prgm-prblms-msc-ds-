# data = (5, 3)  
# data = ['start', 'middle', 'end']  
# data = {'type': 'person', 'name': 'Alice', 'age': 30}  
# data = ['1', [2, 3], [4,5]]  
data = "other"  




match data:
    case (x, y) if x > y:
        print(f"Tuple with x > y: x={x}, y={y}")
    
    case ['start', *rest]:
        print(f"List starting with 'start': rest={rest}")
    
    case {'type': 'person', 'name': name, 'age': age} if age > 18:
        print(f"Adult person: Name={name}, Age={age}")
    
    case [a, [b, c], d]:
        print(f"Nested list: a={a}, b={b}, c={c}, d={d}")
    
    case _:
        print("No match found")
