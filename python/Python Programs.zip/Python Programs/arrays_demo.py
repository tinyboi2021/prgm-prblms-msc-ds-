from array import *

arr = array('i', [1, 3, 7, 14, 9, 6, 7, 20, 4, 10, 5])
new_arr = array(arr.typecode, (elem for elem in arr ))

print(new_arr)




arr = arr.tolist()
arr.sort()
arr = array('i', arr)
print(arr)