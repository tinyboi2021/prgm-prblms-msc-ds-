data = (5, 3)  # Output: Tuple with x > y: x=5, y=3
data = ['start', 'middle', 'end']  # Output: List starting with 'start': rest=['middle', 'end']
data = {'type': 'person', 'name': 'Alice', 'age': 30}  # Output: Adult person: Name=Alice, Age=30
data = [1, [2, 3]]  # Output: Nested list: a=1, b=2, c=3
data = "other"  # Output: No match found


match data:
    # Case 1: Matching a tuple with a specific structure
    case (x, y) if x > y:
        print(f"Tuple with x > y: x={x}, y={y}")
    
    # Case 2: Matching a list with at least three elements, where the first is 'start'
    case ['start', *rest]:
        print(f"List starting with 'start': rest={rest}")
    
    # Case 3: Matching a dictionary with specific keys and values
    case {'type': 'person', 'name': name, 'age': age} if age > 18:
        print(f"Adult person: Name={name}, Age={age}")
    
    # Case 4: Matching a nested structure (e.g., nested list)
    case [a, [b, c]]:
        print(f"Nested list: a={a}, b={b}, c={c}")
    
    # Default case
    case _:
        print("No match found")