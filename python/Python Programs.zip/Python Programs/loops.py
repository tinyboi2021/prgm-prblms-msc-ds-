l = [1, 5, 10, 20, 12]

search = 10

for element in l :
    if element == search :
        print("Found")
        break
    
else :
    print("Not Found")
